import numpy as np

# 建立兩個 NumPy 陣列
a = np.array([1, 2, 3, 4, 5])
b = np.array([10, 20, 30, 40, 50])

# 元素相加
c = a + b
print("元素相加結果：", c)

# 平均值
mean_c = np.mean(c)
print("加總後的平均值：", mean_c)
